use strict;
use warnings;

my $taxa = 1000;
my $state = 4;
my $loops=50;
my $reps=50;
my $method="downpass";

foreach my $rate (0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9,10) {
  my @brier_reps;
  my @num_pred_reps;
  my @jointbs;
  my @num_pred_edge_reps;

  print("\ncalculating birth rate = $rate: \n");
  for (my $loop = 1; $loop <= $loops; $loop++) {
    print("\ntree $loop\n");
    for(my $a = 1; $a <= $reps; $a++){
       print("replicate $a, ");
       system("cp ../../scenarios_$state/rate$rate/simulated_scenario.$rate.$loop.$a.txt ./simulated_scenario.txt");
       system("../../PASTML-v0.6.6.1/PASTML_1 -t ../../trees_$taxa\_original/$taxa.taxa.b.$rate.$loop.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -p $method > output.txt");

	open(FILE, "parsimony.txt") or die "$!";
	my @result = <FILE>;
	close(FILE);
       chomp $result[0];
       push(@brier_reps, $result[0]);
       chomp $result[1];
       push(@jointbs, $result[1]);
       chomp $result[2];
       push(@num_pred_reps, $result[2]);
       chomp $result[3];
       push(@num_pred_edge_reps, $result[3]);

    }
  }
  my $length = $loops * $reps;

#jointBS_calc
  my $pars_jointbs_avg=0.0;
  foreach my $jointbs (@jointbs){
    $pars_jointbs_avg += $jointbs;
  }
  $pars_jointbs_avg /= $length;

#pars_calc
  my $pars_avg=0.0;
  foreach my $brier_reps (@brier_reps){
    $pars_avg += $brier_reps;
  }
  $pars_avg /= $length;

#num_pred_calc
  my $num_pred_avg=0.0;
  foreach my $num_pred_reps (@num_pred_reps){
    $num_pred_avg += $num_pred_reps;
  }
  $num_pred_avg /= $length;

#num_pred_edge_calc
  my $num_pred_edge_avg=0.0;
  foreach my $num_pred_edge_reps (@num_pred_edge_reps){
    $num_pred_edge_avg += $num_pred_edge_reps;
  }
  $num_pred_edge_avg /= $length;

  open(NEWFILE, ">> Results.parsimony.$taxa.$state.$method.txt") or die "$!";
  if($rate==0.1){
    print NEWFILE ("Method = $method\nrate, Brier_Score, Edge_BS, Num_Pred, Num_Pred_Edge\n");
  }
  print NEWFILE ("$rate, $pars_avg, $pars_jointbs_avg, $num_pred_avg, $num_pred_edge_avg\n");
  close (NEWFILE);

  system("rm simulated_scenario.txt parsimony.txt output.txt");
  print("\n\n");
}

