use strict;
use warnings;

my $taxa = 1000;
my $state = 20;
my $loops=50;
my $reps=50;
my $trees="original";
my $model="HKY";

foreach my $rate (0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7) {
	mkdir("rate$rate");
	chdir("rate$rate");
	my @true_states = ();
	my @pars_states = ();
	my $node_num = 0;
	my $node_BS_pars = 0.0;
	my $root_BS_pars_avg = 0.0;
	my @root_BS_pars = {};
	my $node_num_prediction_pars = 0.0;
	my $root_num_prediction_pars_avg = 0.0;
	my @root_num_prediction_pars = {};
	my $edge_BS_pars = 0.0;
	#print("\ncalculating birth rate = $rate: \n");
	for (my $loop = 1; $loop <= $loops; $loop++) {
		#print("\ntree $loop\n");
		mkdir("tree$loop");
		chdir("tree$loop");
		my $edge_count;
		for(my $a = 1; $a <= $reps; $a++){
			#print("rep $a,");
			mkdir("replicate$a");
			chdir("replicate$a");
			system("cp ../../../../reformat_output.py ./");
			system("pastml --work_dir ./ -c residue -d ../../../../../Annotations\_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -t ../../../../../trees_1000\_$trees/$taxa.taxa.b.$rate.$loop.tre -s , --prediction_method DOWNPASS");

			#extract true scenario
			open(FILE, "../../../../../scenarios\_$state/rate$rate/simulated_scenario.$rate.$loop.$a.txt") or die "$!";
			my @file = <FILE>;
			close(FILE);
			my $count = 0;
			foreach my $file (@file) {
				chomp $file;
				if($file =~ /Node0/){ #Root state
					$file =~ s/Node\d+,//;
					$true_states[0] = $file;
				} else {
					$file =~ s/Node\d+,//;
					$true_states[$count+1] = $file;
				}
				$count ++;
			}
			$node_num = $count;

			#extract joint,map,mppa predictions
			system("python3 reformat_output.py -t ../../../../../trees_1000\_$trees/$taxa.taxa.b.$rate.$loop.tre -c residue -d ./combined_ancestral_states.characters_residue.tab -n ./node_pars.tab -e ./edge_pars.tab");
			open(FILE, "node_pars.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			$count = 0;
			foreach my $file (@file) {
				chomp $file;
				$file =~ s/\,/\t/g;
				$file =~ s/\sor\s/,/g;
				my @column = split(/\t/, $file);
				if($count > 0) {
					if($file =~ /ROOT/){
						$pars_states[0] = $column[1];
					} elsif ($file =~ /node/) {
						#print("$column[0]\n");
						$column[0] =~ s/node\_//;
						my $node_id = $column[0] + 1;
						$pars_states[$node_id] = $column[1];
					}
				}
				$count++;
			}

			#compute BS and num mppa predictions for each node
			my $BS_pars = 0.0;
			my $BS_pars_root = 0.0;
			my $edge_pars = 0.0;
			my $num_pars_prediction = 0.0;
			my $num_pars_prediction_root = 0.0;
			for(my $i=0; $i<$node_num; $i++){
				#pars
				my $correct = -1;
				if ($pars_states[$i] =~ /$true_states[$i]/){
					$correct = 1;
				} else {
					$correct = 0;
				}
				my @possibility = split(/,/, $pars_states[$i]);
				$num_pars_prediction += ($#possibility+1);
				if($i==0){
					$num_pars_prediction_root += ($#possibility+1);
				}
				my $prob_possibility = 1.0 / ($#possibility+1);
				if($correct == 0){
					$BS_pars += ( ($prob_possibility - 0.0)**2 )*($#possibility+1);
					$BS_pars += 1.0;
					if($i==0){
						$BS_pars_root += ( ($prob_possibility - 0.0)**2 )*($#possibility+1);
						$BS_pars_root += 1.0;
					}
				} elsif($correct == 1){
					$BS_pars += ( ($prob_possibility - 0.0)**2 )*($#possibility);
					$BS_pars += ( ($prob_possibility - 1.0)**2 );
					if($i==0){
						$BS_pars_root += ( ($prob_possibility - 0.0)**2 )*($#possibility);
						$BS_pars_root += ( ($prob_possibility - 1.0)**2 );
					}
				}
			}

			#compute edge BS
			open(FILE, "edge_pars.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			my $parent=-1;
			my $child=-1;
			$edge_count=0;
			foreach my $file (@file){
				chomp $file;
				#check the parent-child relation

				if($edge_count == 0){
					$edge_count++;
					next;
				}
				my @relation = split(/,/, $file);
				if($relation[0] =~ /ROOT/){
					$parent = 0;
				} elsif ($relation[0] =~ /node/) {
					$relation[0] =~ s/node\_//;
					$parent = $relation[0] + 1;
				}
				if ($relation[1] =~ /node/) {
					$relation[1] =~ s/node\_//;
					$child = $relation[1] + 1;
				}
				if($child == -1 || $parent == -1){
					next;
				}
				#pars edge
				my $correct_parent = -1;
				my $correct_child = -1;
				if ($pars_states[$parent] =~ /$true_states[$parent]/){
					$correct_parent = 1;
				} else {
					$correct_parent = 0;
				}
				if ($pars_states[$child] =~ /$true_states[$child]/){
					$correct_child = 1;
				} else {
					$correct_child = 0;
				}
				my @possib_parent = split(/,/, $pars_states[$parent]);
				my @possib_child = split(/,/, $pars_states[$child]);
				my $prob_possib_parent = 1.0 / ($#possib_parent+1);
				my $prob_possib_child = 1.0 / ($#possib_child+1);
				my $num_comb = ($#possib_parent+1) * ($#possib_child+1);
				if($correct_parent == 1 && $correct_child == 1){
					$edge_pars += ( (($prob_possib_parent * $prob_possib_child) - 0.0)**2 )*($num_comb-1);
					$edge_pars += ( (($prob_possib_parent * $prob_possib_child) - 1.0)**2 );
				} else {
					$edge_pars += ( (($prob_possib_parent * $prob_possib_child) - 0.0)**2 )*($num_comb);
					$edge_pars += 1.0;
				}
				$edge_count++;
			}
			$BS_pars /= $node_num;
			$edge_pars /= ($edge_count-1);
			$num_pars_prediction /= $node_num;

			$node_BS_pars += $BS_pars / $loops / $reps;
			$root_BS_pars_avg += $BS_pars_root / $loops / $reps;
			$edge_BS_pars += $edge_pars / $loops / $reps;
			$node_num_prediction_pars += $num_pars_prediction / $loops / $reps;
			$root_num_prediction_pars_avg += $num_pars_prediction_root / $loops / $reps;
			push(@root_BS_pars, $BS_pars_root);
			push(@root_num_prediction_pars, $num_pars_prediction_root);
			system("rm *.tab named.tree*");
			chdir("..");
		}
		chdir("..");
	}
	#compute 2*SD for root scores
	#my $SD_root_BS_pars = 0.0;
	#my $SD_root_num_pars = 0.0;
	#for (my $loop = 1; $loop <= $loops; $loop++) {
	#	for(my $a = 1; $a <= $reps; $a++){
	#		my $id = $loops*($loop - 1) + ($a - 1) + 1; 
	#		$SD_root_BS_pars += (($root_BS_pars[$id] - $root_BS_pars_avg)**2) / $loops / $reps;
	#		$SD_root_num_pars += (($root_num_prediction_pars[$id] - $root_num_prediction_pars_avg)**2) / $loops / $reps;
	#	}
	#}

 	open(NEWFILE, ">> Results.pars.$taxa.$state.$trees.txt") or die "$!";
	if($rate==0.2){
	print NEWFILE ("rate\tBS_Pars\tRootBS_Pars\tNum_Pred_Pars\tRoot_Num_Pred_Pars\tEdgeBS_Pars\n");
	}
	#my $SD1 = sqrt($SD_root_BS_pars);
	#my $SD2 = sqrt($SD_root_num_pars);
	print NEWFILE ("$rate\t$node_BS_pars\t$root_BS_pars_avg\t$node_num_prediction_pars\t$root_num_prediction_pars_avg\t$edge_BS_pars\n");
	close (NEWFILE);

	#print("\n\n");
	chdir("..");
	system("cat rate$rate/Results.Pars.$taxa.$state.$trees.txt >> Results.Pars.$taxa.$state.$model.$trees.txt");
}

