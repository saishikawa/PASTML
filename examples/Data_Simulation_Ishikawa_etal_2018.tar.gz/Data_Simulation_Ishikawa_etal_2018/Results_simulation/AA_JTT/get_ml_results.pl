use strict;
use warnings;

my $taxa = 1000;
my $state = 20;
my $loops=50;
my $reps=50;
my $trees="original";
my $model="JTT";

foreach my $rate (0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9,10) {
  my @joint_brier_reps;
  my @map_brier_reps;
  my @ma_brier_reps;
  my @marginal_brier_reps;
  my @num_pred_reps;
  my @num_pred_edge_reps;

  my @jointbs_joint;
  my @jointbs_map;
  my @jointbs_ma;
  my @jointbs_marginal;

  print("\ncalculating birth rate = $rate: \n");
  for (my $loop = 1; $loop <= $loops; $loop++) {
    print("\ntree $loop\n");
    for(my $a = 1; $a <= $reps; $a++){
       print("replicate $a, ");
       system("cp ../../scenarios_$state/rate$rate/simulated_scenario.$rate.$loop.$a.txt ./simulated_scenario.txt");
       if($trees eq "original") {
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p joint > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p max_posteriori > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p marginal_approx > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p marginal > output.txt");
       } elsif ($trees eq "flat") {
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.flat.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p joint > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.flat.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p max_posteriori > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.flat.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p marginal_approx > output.txt");
         system("../../PASTML-v0.6.6.1/PASTML -t ../../trees_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.flat.tre -a ../../Annotations_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -m $model -p marginal > output.txt");
        }
       my @result;
	open(FILE, "joint.txt") or die "$!";
	@result = <FILE>;
	close(FILE);
       chomp $result[0];
       push(@joint_brier_reps, $result[0]);
       chomp $result[1];
       push(@jointbs_joint, $result[1]);

	open(FILE, "maximum_posteriori.txt") or die "$!";
	@result = <FILE>;
	close(FILE);
       chomp $result[0];
       push(@map_brier_reps, $result[0]);
       chomp $result[1];
       push(@jointbs_map, $result[1]);

	open(FILE, "marginal_approximation.txt") or die "$!";
	@result = <FILE>;
	close(FILE);
       chomp $result[0];
       push(@ma_brier_reps, $result[0]);
       chomp $result[1];
       push(@jointbs_ma, $result[1]);
       chomp $result[2];
       push(@num_pred_reps, $result[2]);
       chomp $result[3];
       push(@num_pred_edge_reps, $result[3]);

	open(FILE, "marginal.txt") or die "$!";
	@result = <FILE>;
	close(FILE);
       chomp $result[0];
       push(@marginal_brier_reps, $result[0]);
       chomp $result[1];
       push(@jointbs_marginal, $result[1]);
    }
  }

  my $length = $loops * $reps;

#jointBS_calc
  my $joint_jointbs_avg=0.0;
  foreach my $jointbs_joint (@jointbs_joint){
    $joint_jointbs_avg += $jointbs_joint;
  }
  $joint_jointbs_avg /= $length;
  my $map_jointbs_avg=0.0;
  foreach my $jointbs_map (@jointbs_map){
    $map_jointbs_avg += $jointbs_map;
  }
  $map_jointbs_avg /= $length;
  my $ma_jointbs_avg=0.0;
  foreach my $jointbs_ma (@jointbs_ma){
    $ma_jointbs_avg += $jointbs_ma;
  }
  $ma_jointbs_avg /= $length;
  my $marginal_jointbs_avg=0.0;
  foreach my $jointbs_marginal (@jointbs_marginal){
    $marginal_jointbs_avg += $jointbs_marginal;
  }
  $marginal_jointbs_avg /= $length;

#joint_calc
  my $joint_avg=0.0;
  foreach my $joint_brier_reps (@joint_brier_reps){
    $joint_avg += $joint_brier_reps;
  }
  $joint_avg /= $length;

#map_calc
  my $map_avg=0.0;
  foreach my $map_brier_reps (@map_brier_reps){
    $map_avg += $map_brier_reps;
  }
  $map_avg /= $length;

#ma_calc
  my $ma_avg=0.0;
  foreach my $ma_brier_reps (@ma_brier_reps){
    $ma_avg += $ma_brier_reps;
  }
  $ma_avg /= $length;

#marginal_calc
  my $marginal_avg=0.0;
  foreach my $marginal_brier_reps (@marginal_brier_reps){
    $marginal_avg += $marginal_brier_reps;
  }
  $marginal_avg /= $length;

#num_pred_calc
  my $num_pred_avg=0.0;
  foreach my $num_pred_reps (@num_pred_reps){
    $num_pred_avg += $num_pred_reps;
  }
  $num_pred_avg /= $length;

#num_pred_edge_calc
  my $num_pred_edge_avg=0.0;
  foreach my $num_pred_edge_reps (@num_pred_edge_reps){
    $num_pred_edge_avg += $num_pred_edge_reps;
  }
  $num_pred_edge_avg /= $length;


  open(NEWFILE, ">> Results.ml.$taxa.$state.$model.$trees.txt") or die "$!";
  if($rate==0.1){
    print NEWFILE ("Model = $model, Trees = $trees\nrate, BS_Joint, BS_MAP, BS_Marginal, BS_MA, Num_Pred_MA, EdgeBS_Joint, EdgeBS_MAP, EdgeBS_MA, EdgeBS_MARGINAL, Num_Pred_Edge_MA\n");
  }
  print NEWFILE ("$rate, $joint_avg, $map_avg, $marginal_avg, $ma_avg, $num_pred_avg, $joint_jointbs_avg, $map_jointbs_avg, $ma_jointbs_avg, $marginal_jointbs_avg, $num_pred_edge_avg\n");
  close (NEWFILE);

  system("rm simulated_scenario.txt joint.txt marginal.txt marginal_approximation.txt maximum_posteriori.txt output.txt");
  print("\n\n");
}

