use strict;
use warnings;

my $taxa = 1000;
my $branch=0;
my $branchcount=0;
my $average;
my $SIM = 50;
for (my $loopa = 1.0; $loopa <= 10.0; $loopa=$loopa+1.0) {
  for (my $loop = 1; $loop <= $SIM; $loop++) {
    if ($loopa <= 0.9) {
      open(FILE, "$taxa.taxa.b.$loopa.$loop.tre") or last;
    } else {
      open(FILE, "$taxa.taxa.b.$loopa.0.$loop.tre") or last;
    }
    my $pupko = <FILE>;
    close(FILE);
    $pupko =~ s/\:/\n:/g;
    $pupko =~ s/\)/\n/g;
    $pupko =~ s/\,/\n/g;
    open(NEWFILE, "> $taxa.taxa.splitted.txt") or die "$!";
    print NEWFILE $pupko;
    close (NEWFILE);
    open(FILE, "$taxa.taxa.splitted.txt") or die "$!";
    my @file = <FILE>;
    close(FILE);
    foreach my $file (@file) {
      if($file =~ /\:/){
       chomp($file);
       $file =~ s/\://;
       $branch=$branch+$file;
       $branchcount++;
       #print("$branch $branchcount\n");
      }
    }
    $average += $branch / $branchcount;
    $branch=0;
    $branchcount=0;
  }
  $average = $average/$SIM;
  print("Average branch length with birth rate $loopa = $average\n");
  $average=0;
}
