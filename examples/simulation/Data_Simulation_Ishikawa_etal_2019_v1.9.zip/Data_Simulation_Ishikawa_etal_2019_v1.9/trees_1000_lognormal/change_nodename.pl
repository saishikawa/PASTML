use strict;
use warnings;

my $taxa = 1000;
my $state = 4;
my $loops=50;
my $reps=50;
my $trees="original";
my $model="JC";

foreach my $rate (0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7) {
	print("\ncalculating birth rate = $rate: \n");
	for (my $loop = 1; $loop <= $loops; $loop++) {
		open(FILE, "$taxa.taxa.b.$rate.$loop.tre") or die "$!";
		my $file = <FILE>;
		close(FILE);
		$file =~ s/Pastml_Node\_\d+\:/:/g;
		$file =~ s/ROOT//;
		open(NEWFILE, "> tree.txt") or die "$!";
		print NEWFILE $file;
		close(NEWFILE);
		system("rm $taxa.taxa.b.$rate.$loop.tre");
		system("mv tree.txt $taxa.taxa.b.$rate.$loop.tre");
	}
}
