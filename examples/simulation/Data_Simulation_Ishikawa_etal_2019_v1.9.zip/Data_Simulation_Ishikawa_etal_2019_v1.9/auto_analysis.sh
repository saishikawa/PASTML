#!/bin/sh
cd Annotations_4
perl generate_scenario.pl
cd ../Annotations_20
perl generate_scenario.pl
cd ../Results_simulation/Pars_NUC_DOWNPASS
perl get_resultsMP.pl
mv Results* ../Results
cd ../Pars_AA_DOWNPASS
perl get_resultsMP.pl
mv Results* ../Results
cd ../NUC_JC
perl get_resultsNUC.pl
mv Results* ../Results
cd ../NUC_JC_LOG
perl get_resultsNUC.pl
mv Results* ../Results
cd ../NUC_F81
perl get_resultsNUC.pl
mv Results* ../Results
cd ../NUC_F81_LOG
perl get_resultsNUC.pl
mv Results* ../Results
cd ../NUC_HKY
perl get_resultsNUC.pl
mv Results* ../Results
cd ../NUC_HKY_LOG
perl get_resultsNUC.pl
mv Results* ../Results
cd ../AA_JC
perl get_resultsAA.pl
mv Results* ../Results
cd ../AA_JC_LOG
perl get_resultsAA.pl
mv Results* ../Results
cd ../AA_JTT
perl get_resultsAA.pl
mv Results* ../Results
cd ../AA_JTT_LOG
perl get_resultsAA.pl
mv Results* ../Results
cd ../AA_F81
perl get_resultsAA.pl
mv Results* ../Results
cd ../AA_F81_LOG
perl get_resultsAA.pl
mv Results* ../Results
cd ../Results
R R_commands.txt

