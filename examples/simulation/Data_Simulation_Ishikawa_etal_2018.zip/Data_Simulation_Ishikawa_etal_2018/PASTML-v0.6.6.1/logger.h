//
// Created by azhukova on 2/27/18.
//

#ifndef PASTML_LOGGER_H
#define PASTML_LOGGER_H

void log_info(const char* message, ...);

#endif //PASTML_LOGGER_H
