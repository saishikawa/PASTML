//
// Created by saishikawa on 3/12/18.
//

#ifndef PASTML_OUTPUT_SIM_H
#define PASTML_OUTPUT_SIM_H

#include "pastml.h"

int output_simulation(Tree *tree, size_t num_annotations, char **character, char *output_file_path, size_t method_num, char **ID, char **CHAR, int num_nodes);

#endif //PASTML_OUTPUT_SIM_H
