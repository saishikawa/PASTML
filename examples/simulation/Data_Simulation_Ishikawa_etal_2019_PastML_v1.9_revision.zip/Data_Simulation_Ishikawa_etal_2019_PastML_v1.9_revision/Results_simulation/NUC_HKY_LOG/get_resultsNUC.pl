use strict;
use warnings;

my $taxa = 1000;
my $state = 4;
my $loops=50;
my $reps=50;
my $trees="lognormal_SD05";
my $model="HKY";

foreach my $rate (0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8) {
	mkdir("rate$rate");
	chdir("rate$rate");
	my @true_states = ();
	my @joint_states = ();
	my @map_states = ();
	my @mppa_states = ();
	my @marginal_probs = ();
	my $node_num = 0;
	my $lnl_marginal;
	my $lnl_joint;
	my $lnl_map;
	my $lnl_mppa;
	my $fraction_marginal_joint = 0.0;
	my $fraction_marginal_map = 0.0;
	my $fraction_marginal_mppa = 0.0;
	my $node_BS_joint = 0.0;
	my $node_BS_map = 0.0;
	my $node_BS_mppa = 0.0;
	my $node_BS_marginal = 0.0;
	my @root_BS_joint = {};
	my @root_BS_map = {};
	my @root_BS_mppa = {};
	my @root_BS_marginal = {};
	my $root_BS_joint_avg = 0.0;
	my $root_BS_map_avg = 0.0;
	my $root_BS_mppa_avg = 0.0;
	my $root_BS_marginal_avg = 0.0;
	my $node_num_prediction = 0.0;
	my $root_num_prediction = 0.0;
	my @root_num_prediction = {};
	my $root_num_prediction_avg = 0.0;
	my $edge_BS_joint = 0.0;
	my $edge_BS_map = 0.0;
	my $edge_BS_mppa = 0.0;
	my $edge_BS_marginal = 0.0;
	#print("\ncalculating birth rate = $rate: \n");
	for (my $loop = 1; $loop <= $loops; $loop++) {
		mkdir("tree$loop");
		chdir("tree$loop");
		#print("\ntree $loop\n");
		my $edge_count;
		for(my $a = 1; $a <= $reps; $a++){
			mkdir("replicate$a");
			chdir("replicate$a");
			system("cp ../../../../reformat_output.py ./");
			my $id_A = -1;
			my $id_C = -1;
			my $id_G = -1;
			my $id_T = -1;
			#print("rep $a,");
			system("pastml --work_dir ./ -c residue -d ../../../../../Annotations\_$state/rate$rate/Annotation.$taxa.$state.$rate.$loop.$a.txt -t ../../../../../trees\_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -m $model -s , --prediction_method ML");

			#extract true scenario
			open(FILE, "../../../../../scenarios\_$state/rate$rate/simulated_scenario.$rate.$loop.$a.txt") or die "$!";
			my @file = <FILE>;
			close(FILE);
			my $count = 0;
			foreach my $file (@file) {
				chomp $file;
				if($file =~ /Node0/){ #Root state
					$file =~ s/Node\d+,//;
					$true_states[0] = $file;
				} else {
					$file =~ s/Node\d+,//;
					$true_states[$count+1] = $file;
				}
				$count ++;
			}
			$node_num = $count;

			#extract joint,map,mppa predictions
			system("python3.6 reformat_output.py -t ../../../../../trees\_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -c residue_JOINT -d ./combined_ancestral_states.characters_residue_JOINT_residue_MAP_residue_MPPA.tab -m ./marginal_probabilities.character_residue_MPPA.model\_$model.tab -o ./marginal_edge.tab -n ./node_joint.tab -e ./edge_joint.tab");
			open(FILE, "node_joint.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			$count = 0;
			foreach my $file (@file) {
				chomp $file;
				my @column = split(/,/, $file);
				if($count > 0) {
					if($file =~ /ROOT/){
						$joint_states[0] = $column[1];
					} elsif ($file =~ /node/) {
						#print("$column[0]\n");
						$column[0] =~ s/node\_//;
						my $node_id = $column[0] + 1;
						$joint_states[$node_id] = $column[1];
					}
				}
				$count++;
			}
			system("python3.6 reformat_output.py -t ../../../../../trees\_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -c residue_MAP -d ./combined_ancestral_states.characters_residue_JOINT_residue_MAP_residue_MPPA.tab -m ./marginal_probabilities.character_residue_MPPA.model\_$model.tab -o ./marginal_edge.tab -n ./node_map.tab -e ./edge_map.tab");
			open(FILE, "node_map.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			$count = 0;
			foreach my $file (@file) {
				chomp $file;
				my @column = split(/,/, $file);
				if($count > 0) {
					if($file =~ /ROOT/){
						$map_states[0] = $column[1];
					} elsif ($file =~ /node/) {
						#print("$column[0]\n");
						$column[0] =~ s/node\_//;
						my $node_id = $column[0] + 1;
						$map_states[$node_id] = $column[1];
					}
				}
				$count++;
			}
			system("python3.6 reformat_output.py -t ../../../../../trees\_$taxa\_$trees/$taxa.taxa.b.$rate.$loop.tre -c residue_MPPA -d ./combined_ancestral_states.characters_residue_JOINT_residue_MAP_residue_MPPA.tab -m ./marginal_probabilities.character_residue_MPPA.model\_$model.tab -o ./marginal_edge.tab -n ./node_mppa.tab -e ./edge_mppa.tab");
			open(FILE, "node_mppa.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			$count = 0;
			foreach my $file (@file) {
				chomp $file;
				$file =~ s/\,/\t/g;
				$file =~ s/\sor\s/,/g;
				my @column = split(/\t/, $file);
				if($count > 0) {
					if($file =~ /ROOT/){
						$mppa_states[0] = $column[1];
					} elsif ($file =~ /node/) {
						#print("$column[0]\n");
						$column[0] =~ s/node\_//;
						my $node_id = $column[0] + 1;
						$mppa_states[$node_id] = $column[1];
					}
				}
				$count++;
			}

			#extract marginal probabilities (ARNDCQEGHILKMFPSTWYV)
			open(FILE, "marginal_probabilities.character_residue_MPPA.model\_$model.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			$count = 0;
			my $not_predicted = 0;
			foreach my $file (@file) {
				chomp $file;
				my @column = split(/\t/, $file);
				if($count > 0) {
					for(my $j=0; $j<=$not_predicted; $j++){
						push(@column,"0.0");
					}
					if($file =~ /ROOT/){
						$marginal_probs[0] = ($column[$id_A].",".$column[$id_C].",".$column[$id_G].",".$column[$id_T]);
						#print("node 0 $marginal_probs[0]\n");
					} elsif ($file =~ /node/) {
						$column[0] =~ s/node\_//;
						my $node_id = $column[0] + 1;
						$marginal_probs[$node_id] = ($column[$id_A].",".$column[$id_C].",".$column[$id_G].",".$column[$id_T]);
						#print("node $node_id $marginal_probs[$node_id]\n");
					}
				} elsif($count == 0) {
					my $length = @column;
					for(my $i=1; $i<$length; $i++){
						if($column[$i] =~ /A/){
							$id_A = $i;	
						} elsif ($column[$i] =~ /C/) { 
							$id_C = $i;
						} elsif ($column[$i] =~ /G/) { 
							$id_G = $i;
						} elsif ($column[$i] =~ /T/) { 
							$id_T = $i;
						}
					}

					if($id_A < 0){
						$length++;
						$id_A = $length-1;
						$not_predicted++;
					}
					if($id_C < 0){
						$length++;
						$id_C = $length-1;
						$not_predicted++;
					}
					if($id_G < 0){
						$length++;
						$id_G = $length-1;
						$not_predicted++;
					} 
					if($id_T < 0){
						$length++;
						$id_T = $length-1;
						$not_predicted++;
					}
					#print("$id_A,$id_C,$id_G,$id_T\n");
					#print("$id_A,$id_R,$id_N,$id_D,$id_C,$id_Q,$id_E,$id_G,$id_H,$id_I,$id_L,$id_K,$id_M,$id_F,$id_P,$id_S,$id_T,$id_W,$id_Y,$id_V\n");
				}
				$count++;
			}
			#compute likelihood fraction
			open(FILE, "params.character_residue_MPPA.method_MPPA.model\_$model.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			foreach my $file (@file){
				chomp $file;
				if($file =~ /log_likelihood\t/){
					$file =~ s/log_likelihood\t//;
					$lnl_marginal = $file;
				} elsif($file =~ /log_likelihood_restricted_JOINT/) {
					$file =~ s/log_likelihood_restricted_JOINT\t//;
					$lnl_joint = $file;
				} elsif($file =~ /log_likelihood_restricted_MAP/) {
					$file =~ s/log_likelihood_restricted_MAP\t//;
					$lnl_map = $file;
				} elsif($file =~ /log_likelihood_restricted_MPPA/) {
					$file =~ s/log_likelihood_restricted_MPPA\t//;
					$lnl_mppa = $file;
				}
			}
			$fraction_marginal_joint += ($lnl_marginal - $lnl_joint) / $loops / $reps;
			$fraction_marginal_map += ($lnl_marginal - $lnl_map) / $loops / $reps;
			$fraction_marginal_mppa += ($lnl_marginal - $lnl_mppa) / $loops / $reps;
	
			#compute BS and num mppa predictions for each node
			my $BS_joint = 0.0;
			my $BS_map = 0.0;
			my $BS_mppa = 0.0;
			my $BS_marginal = 0.0;
			my $BS_joint_root = 0.0;
			my $BS_map_root = 0.0;
			my $BS_mppa_root = 0.0;
			my $BS_marginal_root = 0.0;
			my $edge_joint = 0.0;
			my $edge_map = 0.0;
			my $edge_mppa = 0.0;
			my $edge_marginal = 0.0;
			my $num_mppa_prediction = 0.0;
			my $num_mppa_prediction_root = 0.0;
			for(my $i=0; $i<$node_num; $i++){
				#joint
				if($true_states[$i] =~ $joint_states[$i]){
					$BS_joint += 0.0;
					if($i==0){
						$BS_joint_root += 0.0;
					}
				} else {
					$BS_joint += 2.0;
					if($i==0){
						$BS_joint_root += 2.0;
					}
				}
				#map
				if($true_states[$i] =~ $map_states[$i]){
					$BS_map += 0.0;
					if($i==0){
						$BS_map_root += 0.0;
					}
				} else {
					$BS_map += 2.0;
					if($i==0){
						$BS_map_root += 2.0;
					}
				}
				#mppa
				my $correct = -1;
				if ($mppa_states[$i] =~ /$true_states[$i]/){
					$correct = 1;
				} else {
					$correct = 0;
				}
				my @possibility = split(/,/, $mppa_states[$i]);
				$num_mppa_prediction += ($#possibility+1);
				if($i==0){
					$num_mppa_prediction_root += ($#possibility+1);
				}
				my $prob_possibility = 1.0 / ($#possibility+1);
				if($correct == 0){
					$BS_mppa += ( ($prob_possibility - 0.0)**2 )*($#possibility+1);
					$BS_mppa += 1.0;
					if($i==0){
						$BS_mppa_root += ( ($prob_possibility - 0.0)**2 )*($#possibility+1);
						$BS_mppa_root += 1.0;
					}
				} elsif($correct == 1){
					$BS_mppa += ( ($prob_possibility - 0.0)**2 )*($#possibility);
					$BS_mppa += ( ($prob_possibility - 1.0)**2 );
					if($i==0){
						$BS_mppa_root += ( ($prob_possibility - 0.0)**2 )*($#possibility);
						$BS_mppa_root += ( ($prob_possibility - 1.0)**2 );
					}
				}
				#marginal (ARNDCQEGHILKMFPSTWYV)
				my @posterior = split(/,/, $marginal_probs[$i]);
				if($true_states[$i] =~ /A/){
					$correct = 0;
				} elsif($true_states[$i] =~ /C/) {
					$correct = 1;
				} elsif($true_states[$i] =~ /G/) {
					$correct = 2;
				} elsif($true_states[$i] =~ /T/) {
					$correct = 3;
				}
				for(my $j=0; $j<@posterior; $j++){
					if($posterior[$j] ne ""){
						if($j == $correct){
							$BS_marginal += ( ($posterior[$j] - 1.0) )**2;
							if($i==0){
								$BS_marginal_root += ( ($posterior[$j] - 1.0) )**2;
							}
						} else {
							$BS_marginal += ( ($posterior[$j] - 0.0) )**2;
							if($i==0){
								$BS_marginal_root += ( ($posterior[$j] - 0.0) )**2;
							}
						}
					}
				}
			}

			#compute edge BS
			open(FILE, "edge_joint.tab") or die "$!";
			@file = <FILE>;
			close(FILE);
			my $parent=-1;
			my $child=-1;
			$edge_count=0;
			foreach my $file (@file){
				$parent=-1;
				$child=-1;
				chomp $file;
				#check the parent-child relation

				if($edge_count == 0){
					$edge_count++;
					next;
				}
				my @relation = split(/,/, $file);
				if($relation[0] =~ /ROOT/){
					$parent = 0;
				} elsif ($relation[0] =~ /node/) {
					$relation[0] =~ s/node\_//;
					$parent = $relation[0] + 1;
				}
				if ($relation[1] =~ /node/) {
					$relation[1] =~ s/node\_//;
					$child = $relation[1] + 1;
				}
				if($child == -1 || $parent == -1){
					next;
				}
				#Joint edge
				if( ($true_states[$parent] =~ $joint_states[$parent]) && ($true_states[$child] =~ $joint_states[$child]) ){
					$edge_joint += 0.0;
				} else {
					$edge_joint += 2.0;
				}
				#MAP edge
				if( ($true_states[$parent] =~ $map_states[$parent]) && ($true_states[$child] =~ $map_states[$child]) ){
					$edge_map += 0.0;
				} else {
					$edge_map += 2.0;
				}
				#mppa edge
				my $correct_parent = -1;
				my $correct_child = -1;
				if ($mppa_states[$parent] =~ /$true_states[$parent]/){
					$correct_parent = 1;
				} else {
					$correct_parent = 0;
				}
				if ($mppa_states[$child] =~ /$true_states[$child]/){
					$correct_child = 1;
				} else {
					$correct_child = 0;
				}
				my @possib_parent = split(/,/, $mppa_states[$parent]);
				my @possib_child = split(/,/, $mppa_states[$child]);
				my $prob_possib_parent = 1.0 / ($#possib_parent+1);
				my $prob_possib_child = 1.0 / ($#possib_child+1);
				my $num_comb = ($#possib_parent+1) * ($#possib_child+1);
				if($correct_parent == 1 && $correct_child == 1){
					$edge_mppa += ( (($prob_possib_parent * $prob_possib_child) - 0.0)**2 )*($num_comb-1);
					$edge_mppa += ( (($prob_possib_parent * $prob_possib_child) - 1.0)**2 );
				} else {
					$edge_mppa += ( (($prob_possib_parent * $prob_possib_child) - 0.0)**2 )*($num_comb);
					$edge_mppa += 1.0;
				}
				#marginal edge
				my @post_parent = split(/,/, $marginal_probs[$parent]);
				my @post_child = split(/,/, $marginal_probs[$child]);
				$num_comb = ($#post_parent+1) * ($#post_child+1);
				if($true_states[$parent] =~ /A/){
					$correct_parent = 0;
				} elsif($true_states[$parent] =~ /C/) {
					$correct_parent = 1;
				} elsif($true_states[$parent] =~ /G/) {
					$correct_parent = 2;
				} elsif($true_states[$parent] =~ /T/) {
					$correct_parent = 3;
				}
				if($true_states[$child] =~ /A/){
					$correct_child = 0;
				} elsif($true_states[$child] =~ /C/) {
					$correct_child = 1;
				} elsif($true_states[$child] =~ /G/) {
					$correct_child = 2;
				} elsif($true_states[$child] =~ /T/) {
					$correct_child = 3;
				}
				for(my $j=0; $j<$#post_parent+1; $j++){
					for(my $k=0; $k<$#post_child+1; $k++){
						if( ($post_parent[$j] ne "") && ($post_child[$k] ne "") ){
							if( ($j == $correct_parent) && ($k == $correct_child) ){
								$edge_marginal += ( ( ($post_parent[$j]*$post_child[$k]) - 1.0) )**2;
							} else {
								$edge_marginal += ( ( ($post_parent[$j]*$post_child[$k]) - 0.0) )**2;
							}
						}
					}
				}
				$edge_count++;
			}

			$BS_joint /= $node_num;
			$BS_map /= $node_num;
			$BS_mppa /= $node_num;
			$BS_marginal /= $node_num;
			$edge_joint /= ($edge_count-1);
			$edge_map /= ($edge_count-1);
			$edge_mppa /= ($edge_count-1);
			$edge_marginal /= ($edge_count-1);
			$num_mppa_prediction /= $node_num;

			$node_BS_joint += $BS_joint / $loops / $reps;
			$node_BS_map += $BS_map / $loops / $reps;
			$node_BS_mppa += $BS_mppa / $loops / $reps;
			$node_BS_marginal += $BS_marginal / $loops / $reps;

			$root_BS_joint_avg += $BS_joint_root / $loops / $reps;
			$root_BS_map_avg += $BS_map_root / $loops / $reps;
			$root_BS_mppa_avg += $BS_mppa_root / $loops / $reps;
			$root_BS_marginal_avg += $BS_marginal_root / $loops / $reps;

			push(@root_BS_joint, $BS_joint_root);
			push(@root_BS_map, $BS_map_root);
			push(@root_BS_mppa, $BS_mppa_root);
			push(@root_BS_marginal, $BS_marginal_root);

			$edge_BS_joint += $edge_joint / $loops / $reps;
			$edge_BS_map += $edge_map / $loops / $reps;
			$edge_BS_mppa += $edge_mppa / $loops / $reps;
			$edge_BS_marginal += $edge_marginal / $loops / $reps;
			$node_num_prediction += $num_mppa_prediction / $loops / $reps;
			$root_num_prediction_avg += $num_mppa_prediction_root / $loops / $reps;
			push(@root_num_prediction, $num_mppa_prediction_root);

			system("rm *.tab named.tree*");
			open(NEWFILE, "> log_BSs.txt") or die "$!";
			print NEWFILE "$BS_joint\t$BS_map\t$BS_mppa\t$BS_marginal\t$num_mppa_prediction\t$BS_joint_root\t$BS_map_root\t$BS_mppa_root\t$BS_marginal_root\t$num_mppa_prediction_root\t$edge_joint\t$edge_map\t$edge_mppa\t$edge_marginal\n";
            close(NEWFILE);
			chdir("..");
		}
		chdir("..");
	}
	#compute 2*SD for root scores
	my $SD_root_BS_joint = 0.0;
	my $SD_root_BS_map = 0.0;
	my $SD_root_BS_mppa = 0.0;
	my $SD_root_BS_marginal = 0.0;
	#my $SD_root_num_mppa = 0.0;
	for (my $loop = 1; $loop <= $loops; $loop++) {
		for(my $a = 1; $a <= $reps; $a++){
			my $id = $loops*($loop - 1) + ($a - 1) + 1; 
			$SD_root_BS_joint += (($root_BS_joint[$id] - $root_BS_joint_avg)**2) / $loops / $reps;
			$SD_root_BS_map += (($root_BS_map[$id] - $root_BS_map_avg)**2) / $loops / $reps;
			$SD_root_BS_mppa += (($root_BS_mppa[$id] - $root_BS_mppa_avg)**2) / $loops / $reps;
			$SD_root_BS_marginal += (($root_BS_marginal[$id] - $root_BS_marginal_avg)**2) / $loops / $reps;
	#		$SD_root_num_mppa += (($root_num_prediction[$id] - $root_num_prediction_avg)**2) / $loops / $reps;
		}
	}

	my $SD1 = sqrt($SD_root_BS_joint) / sqrt($loops*$reps) * 1.96;
	my $SD2 = sqrt($SD_root_BS_map) / sqrt($loops*$reps) * 1.96;
	my $SD3 = sqrt($SD_root_BS_mppa) / sqrt($loops*$reps) * 1.96;
	my $SD4 = sqrt($SD_root_BS_marginal) / sqrt($loops*$reps) * 1.96;
	#my $SD5 = sqrt($SD_root_num_mppa);
 	open(NEWFILE, ">> Results.ml.$taxa.$state.$model.$trees.txt") or die "$!";
	if($rate==0.2){
		print NEWFILE ("rate\tBS_Joint\tBS_MAP\tBS_MPPA\tBS_Marginal\tNum_Pred_MA\tRootBS_Joint\tSE\tRootBS_MAP\tSE\tRootBS_MPPA\tSE\tRootBS_Marginal\tSE\tRoot_Num_Pred_MA\tEdgeBS_Joint\tEdgeBS_MAP\tEdgeBS_MPPA\tEdgeBS_MARGINAL\n");
	}
	print NEWFILE ("$rate\t$node_BS_joint\t$node_BS_map\t$node_BS_mppa\t$node_BS_marginal\t$node_num_prediction\t$root_BS_joint_avg\t$SD1\t$root_BS_map_avg\t$SD2\t$root_BS_mppa_avg\t$SD3\t$root_BS_marginal_avg\t$SD4\t$root_num_prediction_avg\t$edge_BS_joint\t$edge_BS_map\t$edge_BS_mppa\t$edge_BS_marginal\n");
	close (NEWFILE);

	#print("\n\n");
	chdir("..");
	system("cat rate$rate/Results.ml.$taxa.$state.$model.$trees.txt >> Results.ml.$taxa.$state.$model.$trees.txt");
}
