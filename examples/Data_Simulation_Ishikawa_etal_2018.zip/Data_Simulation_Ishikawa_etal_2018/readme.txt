The dataset is used in the simulation study performed by Ishikawa et al. 2018 (in preparation).
Brief description for each repository;

trees_1000_original : the pure-birth 1000-tips trees generated for 0.1 - 10 speciation substitution rate ratios
trees_1000_flat : same trees with those in 'trees_1000_original' except that their branch lengths are averaged (flattened)
Annotations_4 : tip annotations (DNA-like data) generated on the original 1000-tips trees with the HKY model
Annotations_20 : tip annotations (protein-like data) generated on the original 1000-tips trees with the JTT model
scenarios_4 : the list of true ancestral states (A, T, G or C) for all internal nodes of the original tree, which were observed in the data generation
scenarios_20 : the list of true ancestral states (20 amino-acids) for all internal nodes of the original tree, which were observed in the data generation
PASTML-v0.6.6.1 : PASTML source code and binary to be used in the ancestral state reconstruction
Seq-Gen.v.1.3.3 : Seq-Gen source code and binary to be used in the data simulation
Results_simulation: output directories to contain the summary statistics for the accuracy of the ML- and Parsimony-based ancestral reconstruction. R commands are included to visualize the results.

To automatically analyze the data;
./auto_analysis.sh

Please see the paper for details of the simulation procedure.