import pandas as pd

from pastml.annotation import preannotate_tree
from pastml import col_name2cat
from pastml.tree import read_tree, name_tree, collapse_zero_branches

if '__main__' == __name__:
    import argparse

    parser = argparse.ArgumentParser(description="Reformatting ancestral state files.")

    tree_group = parser.add_argument_group('tree-related arguments')
    tree_group.add_argument('-t', '--tree', help="tree in newick format (must be rooted).",
                            type=str, required=True)
    acr_group = parser.add_argument_group('acr-file-related arguments')
    acr_group.add_argument('-c', '--column', help="character of interest", type=str, default=None)
    acr_group.add_argument('-d', '--data', required=True, type=str,
                           help="path to the pastml output annotation file "
                                "with the reconstructed ancestral character states.")
    acr_group.add_argument('-m', '--mp_file', required=False, default=None, type=str,
                           help="path to the pastml output marginal probabilities file.")
    out_group = parser.add_argument_group('output-related arguments')
    out_group.add_argument('-n', '--node_file', required=True, type=str,
                           help="path to the node annotation file with multiple states joined via or.")
    out_group.add_argument('-e', '--edge_file', required=True, type=str,
                           help="path to the edge annotation file with multiple states joined via or.")
    out_group.add_argument('-o', '--edge_mp_file', required=False, default=None, type=str,
                           help="path to the marginal probabilities edge file.")

    params = parser.parse_args()

    root = read_tree(params.tree)
    name_tree(root)
    collapse_zero_branches(root)

    df = pd.read_table(params.data, index_col=0, header=0, dtype=str)
    column = col_name2cat(params.column) if params.column else df.columns[0]
    df = df[[column]]
    df.index = df.index.map(str)

    preannotate_tree(df, root)

    with open(params.node_file, 'w+') as node_f:
        node_f.write('ID,state\n')
        with open(params.edge_file, 'w+') as edge_f:
            edge_f.write('Parent ID,Child ID,Parent state,Child state\n')
            for n in root.traverse('preorder'):
                n.add_feature(column, ' or '.join(sorted(getattr(n, column, set()))))
                node_f.write('{},{}\n'.format(n.name, getattr(n, column)))
                if not n.is_root():
                    edge_f.write('{},{},{},{}\n'.format(n.up.name, n.name, getattr(n.up, column), getattr(n, column)))

    if params.mp_file and params.edge_mp_file:
        df = pd.read_table(params.mp_file, index_col=0, header=0)
        df.index = df.index.map(str)
        with open(params.edge_mp_file, 'w+') as f:
            f.write('Parent ID,Child ID,{},{}\n'.format(','.join('Parent {}'.format(_) for _ in df.columns),
                                                        ','.join('Child {}'.format(_) for _ in df.columns)))
            for n in root.traverse('preorder'):
                if not n.is_root():
                    f.write('{},{},{},{}\n'.format(n.up.name, n.name, ','.join(df.loc[n.up.name, :].astype(str)),
                                                   ','.join(df.loc[n.name, :].astype(str))))



