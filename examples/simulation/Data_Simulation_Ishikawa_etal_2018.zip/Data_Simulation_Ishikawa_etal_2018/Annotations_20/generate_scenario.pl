use strict;
use warnings;

my $taxa = 1000;
my $state = 20;
my $trees=50;
my $reps=50;

foreach my $rate (0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1,2,3,4,5,6,7,8,9,10) {
  print("calculation birthrate = $rate: \n");
  mkdir("rate$rate");
  chdir("rate$rate");
  for (my $loop = 1; $loop <= $trees; $loop++) {
      print("tree $loop, ");
      for (my $a = 1; $a <= $reps; $a++) {
        my $seed = int(rand(90000000))+10000000;
        system("../../Seq-Gen.v1.3.3/source/seq-gen -mJTT -l1 -wa -q -z$seed < ../../trees_1000_original/$taxa.taxa.b.$rate.$loop.tre > test.txt");
        system("grep Node test.txt > ../../scenarios_20/rate$rate/simulated_scenario.$rate.$loop.$a.txt");
        system("grep \"^t\" test.txt > ./Annotation.$taxa.$state.$rate.$loop.$a.txt");
      }
   }
   chdir("..");
   printf("\n");
}

